package com.multi.homework;

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.eat();
        dog.sound();
        dog.move();

        Cat cat = new Cat();
        cat.eat();
        cat.sound();
        cat.move();
    }
}
