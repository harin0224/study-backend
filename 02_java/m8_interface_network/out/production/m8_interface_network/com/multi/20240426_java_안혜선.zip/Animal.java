package com.multi.homework;

public interface Animal {
    void eat();
    void sound();
}
