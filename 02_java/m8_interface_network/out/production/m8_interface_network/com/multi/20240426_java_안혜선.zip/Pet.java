package com.multi.homework;

public abstract class Pet implements Animal{
    @Override
    public abstract void eat();
    @Override
    public abstract void sound();

    abstract void move();
}
