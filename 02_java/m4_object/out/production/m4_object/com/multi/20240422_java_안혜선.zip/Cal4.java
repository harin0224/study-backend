package com.multi.homework;

public class Cal4 {
    public int sum(int count, int price) {
        return count * price;
    }
    public int div(int sum, int person) {
        return sum / person;
    }
    // 2개의 입력값을 더해서 총금액을 구하는 메서드
    public int total(int sum1, int sum2) {
        return sum1 + sum2;
    }
}

