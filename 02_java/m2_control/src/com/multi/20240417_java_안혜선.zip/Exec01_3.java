package com.multi.homework;

import javax.swing.*;

public class Exec01_3 {
    public static void main(String[] args) {
        double width = 22.2;
        double height = 33.3;

        double area = width * height;
        JOptionPane.showMessageDialog(null, "사각형의 넓이는 " + area + "입니다.");
    }
}
