-- CONNECTION: url=jdbc:oracle:thin:@//localhost:1521/XE
-- New script in localhost 6.
-- Connection Type: dev 
-- Url: jdbc:oracle:thin:@//localhost:1521/XE
-- workspace : C:\Users\daten\AppData\Roaming\DBeaverData\workspace6
-- Date: 2024. 5. 3.
-- Time: 오후 5:09:28

CREATE USER mouce IDENTIFIED BY 1111;
GRANT CONNECT TO mouce;