-- CONNECTION: url=jdbc:oracle:thin:@//localhost:1521/XE
-- New script in localhost 5.
-- Connection Type: dev 
-- Url: jdbc:oracle:thin:@//localhost:1521/XE
-- workspace : C:\Users\daten\AppData\Roaming\DBeaverData\workspace6
-- Date: 2024. 5. 3.
-- Time: 오후 3:26:33


CREATE TABLE TEST
	(ID varchar2(100));
	

 DROP TABLE TEST;