-- CONNECTION: url=jdbc:oracle:thin:@//localhost:1521/XE
-- New script in localhost 2_HR.
-- Connection Type: dev 
-- Url: jdbc:oracle:thin:@//localhost:1521/XE
-- workspace : D:\workspace\multi\04_db
-- Date: 2024. 5. 8.
-- Time: 오전 10:44:16

SELECT *FROM EMPLOYEES ;